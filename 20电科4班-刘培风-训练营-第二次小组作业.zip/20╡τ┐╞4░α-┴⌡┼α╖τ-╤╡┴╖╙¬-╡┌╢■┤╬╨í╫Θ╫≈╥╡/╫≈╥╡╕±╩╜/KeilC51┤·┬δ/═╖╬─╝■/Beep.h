#ifndef __BEEP_H__
#define __DBEEP_H__
#include <REGX52.H>
sbit beep = P3^3;

#endif