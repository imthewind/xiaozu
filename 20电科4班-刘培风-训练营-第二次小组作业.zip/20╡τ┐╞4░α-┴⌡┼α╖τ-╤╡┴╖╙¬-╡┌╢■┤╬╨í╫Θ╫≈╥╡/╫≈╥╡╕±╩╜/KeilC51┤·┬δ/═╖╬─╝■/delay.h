#ifndef __DELAY_H__
#define __DELAY_H__
#include <REGX52.H>
void Delay(unsigned int xms);

#endif